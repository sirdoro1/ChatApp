<?php

$servername = "localhost";
$username = "serihiuv_chatapp";
$password = "engineer1828";

try {
    $conn = new PDO("mysql:host=$servername;dbname=serihiuv_chatapp", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    }
catch(PDOException $e)
    {
    echo "Connection failed: " . $e->getMessage();
    }
?> 