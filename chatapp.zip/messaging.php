<?php
include('connection.php');

$user = $text = '';
$userError = $textError = '';

if($_SERVER['REQUEST_METHOD']=='POST'){

        echo $_POST['sender'];
        $user = test_input($_POST['sender']);

        $text = test_input($_POST['text']);

        $date = date('Y-m-d h:i:s',time());


    if(empty($userError) && empty($textError)){
        try {
            $sql = "INSERT INTO messages (user, text, created_at, updated_at) VALUES ('$user', '$text', '$date', '$date')";
            $conn->exec($sql);
            
        }catch(PDOException $e)
            {
                echo "Check Network Connection";
            // echo $sql . "<br>" . $e->getMessage();
            }
        $conn = null;
    }
    
}

function test_input($data){
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}



?>