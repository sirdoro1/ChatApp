<?php
include('connection.php');

$test = $conn->prepare("SELECT * FROM messages");
$test->execute();

while($row = $test->fetch(PDO::FETCH_ASSOC)){
    $messages[]=$row;
}
echo json_encode($messages);
